#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :统计人物.py
# @Time      :2023/5/16 15:24
# @Author    :周万宁


if __name__ == "__main__":
    run_code = 0
import jieba.posseg as pseg

# 读取文本内容
with open('红楼梦.txt', 'r', encoding='utf-8') as f:
    document = f.read()

# 使用名为 names.txt 的文件作为参考，来挑选小说文本中的姓名
with open('names.txt', 'r', encoding='utf-8') as f:
    names = set([line.strip() for line in f.readlines()])

# 统计人名出现的次数
word_counts = {}
for word, flag in pseg.cut(document):
    # 只保留显式地被识别为人名或自定义姓氏的词语
    if flag == 'nr' or word in names:
        word_counts[word] = word_counts.get(word, 0) + 1

# 获取出现次数最多的前10个人名
top_10 = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)[:10]

# 输出结果
for name, count in top_10:
    print(name, count)
