#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :openpyxl_IO.py
# @Time      :2023/5/16 13:45
# @Author    :周万宁

# 导入openpyxl
import openpyxl



if __name__ == "__main__":
    run_code = 0

# 创建openpyxl工作库
wb = openpyxl.Workbook()

# 获取第一个工作表
sheet = wb.active

# 在A1单元格子中写入文本
sheet['A1'] = 'hello world'

# 保存文件
filename = 'example.xlsx'
wb.save(filename)

