#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :fileIO.py
# @Time      :2023/5/16 13:44
# @Author    :周万宁


if __name__ == "__main__":
    run_code = 0

with open("example.txt", "w") as f:
    # 向文件中写入一行文本
    f.write("Hello world!")